﻿using CDInterviewQuestions.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebGrease.Css.Extensions;

namespace CDInterviewQuestions.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        //GET
        public ActionResult Characters(string result)
        {
            ViewBag.Result = result;
            return View();
        }

        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Characters(string char1, string char2)
        {
            if (char1 != null && char2 != null)
            {
                List<char> char1List = char1.ToLower().ToCharArray().ToList();
                List<char> char2List = char2.ToLower().ToCharArray().ToList();
                //I first accomplished this by using a nested foreach loop, 
                //but then I remembered about the Intersect LINQ statement and found that it produced the same result more efficiently.
                List<char> common = char1List.Intersect(char2List).Where(c => c != ' ').ToList();

                //Below is my nested foreach loop. I left this here because I assume that this is likely what you're looking for.
                //foreach (var character in char1List)
                //{
                //    foreach(var character2 in char2List)
                //    {
                //        if(character == character2 && !common.Contains(character) && character != ' ')
                //        {
                //            common.Add(character);
                //        }
                //    }
                //}
                ViewBag.Result = String.Join("", common);
                return View();
            }
            ViewBag.Result = "There was an error with your input. Please try again.";
            return View();
        }

        //GET
        public ActionResult Primes()
        {
            return View();
        }

        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Primes(int? number)
        {
            if (number > 1 && number != null)
            {
                int intNum = Convert.ToInt32(number);
                List<int> primes = new List<int>();
                bool isPrime = false;
                for (int i = intNum; i > 1; i--)
                {
                    if (i == 2)
                    {
                        isPrime = true;
                    }
                    else if (i == 3)
                    {
                        isPrime = true;
                    }
                    else
                    {
                        //No point testing i/j if j > i/2 because i/2 will produce the next whole number.
                        //This restriction cuts out half of the loop iterations, but does not catch 2 or 3 as prime numbers.
                        for (int j = Convert.ToInt32(Math.Ceiling((decimal)(i / 2))); j > 1; j--)
                        {
                            if (i % j == 0)
                            {
                                isPrime = false;
                                break;
                            }
                            else if (j != 2)
                            {
                                isPrime = false;
                            }
                            else
                            {
                                isPrime = true;
                                break;
                            }
                        }
                    }
                    if (isPrime)
                    {
                        primes.Add(i);
                    }
                }

                int count = primes.Count();
                string primeList = String.Join(", ", primes.ToArray().Reverse().ToList());
                ViewBag.Result = String.Format("There are {0} primes numbers. <br/>The numbers are {1}", count, primeList);
                return View();
            }
            ViewBag.Result = "There was an error with your input. Please try again.";
            return View();
        }

        //GET
        public ActionResult Reverse()
        {
            return View();
        }

        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Reverse(string sentence)
        {
            if (sentence != null)
            {
                List<string> backwards = sentence.Split(' ').Reverse().ToList();

                ViewBag.Result = String.Join(" ", backwards);
                return View();
            }
            ViewBag.Result = "There was an error with your input. Please try again.";
            return View();
        }

    }
}